﻿using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;

/// @author $username$
/// @version ..$year$
/// <summary>
/// 
/// </summary>
public class $safeprojectname$
{
    /// <summary>
    /// 
    /// </summary>
    public static void Main()
    {

    }

}