﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Jypeli;

public class $safeprojectname$ : PhysicsGame
{
    public override void Begin()
    {
    }
}
